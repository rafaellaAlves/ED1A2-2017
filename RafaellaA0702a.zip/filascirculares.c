#include "filascirculares.h"
#include <stdio.h>
#include <stdlib.h>

void iniciarFila (struct Fila* f){
    int i;
    
    for(i=0; i < MAX_ELEM; i++){
        f->elem[i] = 0;
    }
    
    f->inicio = FILA_VAZIA;
    f->final = FILA_VAZIA;
}

int vazia(struct Fila f){
    if(f.inicio == FILA_VAZIA){
        return SIM;
    }else{
        return NAO;
    }            
                
}

int cheia(struct Fila f){
    if((f.inicio == 0 && f.final == MAX_ELEM-1)||(f.inicio == f.final+1)){
        printf("\nFila cheia!");
        return SIM;
    }else{
        printf("\nA fila nao esta cheia!");
        return NAO;
    }    
}

void listarElementos (struct Fila f){
    int i;
    
    if (vazia(f)){
        printf("\nFila vazia! Nao e possivel listar os elementos.");
    }else{
        printf("\n\nOs elementos da lista sao:\n");
        for(i=f.inicio; i!= f.final ; i=((i+1)%MAX_ELEM)){
            printf("%c ", f.elem[i]);
        }
    }    
}

int inserir (struct Fila* f, char dado){
    if((f->inicio == 0 && f->final == MAX_ELEM-1)||(f->inicio == f->final+1))
        printf("\nNao e possivel inserir! FILA CHEIA.");
    else{
        if(f->inicio == FILA_VAZIA)
            f->inicio++;
        f->final = (f->final+1)%MAX_ELEM;
        f->elem[f->final] = dado;
    }
}

char remover (struct Fila* f){
    char e = 0;
    int i =0;
    
    if(f->inicio != FILA_VAZIA){
        e = obterInicio(*f);
        f->elem[f->inicio] = 0;
        f->inicio++;
    }else{    
        if(f->inicio == f->final){
            f->inicio = FILA_VAZIA;
            f->final = FILA_VAZIA;
        }else
            f->inicio = (f->inicio+1)%MAX_ELEM;
    }
}

char obterInicio(struct Fila f){
    char dado = 0;
    
    if (f.inicio == FILA_VAZIA)
        printf("\nFila vazia! Nao e possivel obter inicio.");
    else{
        dado = f.elem[f.inicio];
    }
    return dado;
}

int size(struct Fila f){
    if(f.inicio <= f.final)
        return f.final - f.inicio+1;
    return((MAX_ELEM - f.inicio)+(f.final+1));
}
