
#ifndef FILASCIRCULARES_H
#define FILASCIRCULARES_H

#define MAX_ELEM 10
#define FILA_VAZIA -1
#define SIM 1
#define NAO 0

struct Fila {
    int inicio;
    int final;
    char elem[MAX_ELEM];
}; 

void iniciarFila(struct Fila*);
void listarElementos(struct Fila);
int inserir(struct Fila*, char);
char remover(struct Fila*);
int vazia(struct Fila);
int cheia(struct Fila);
int size (struct Fila);
char obterInicio (struct Fila);

#endif /* FILASCIRCULARES_H */

