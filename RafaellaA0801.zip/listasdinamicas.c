#include "listasdinamicas.h"
#include <stdio.h>
#include <stdlib.h>

//inicializar as structs nó/
struct No *inicio;
struct No *n1 = NULL;
struct No *n2 = NULL;
struct No *n3 = NULL;

void montarLista(){
    
    //alocar na memoria usando o malloc//
    n1 = malloc(sizeof(struct No));
    n2 = malloc(sizeof(struct No));
    n3 = malloc(sizeof(struct No));
    
    //inicializar valores nos nós//
    n1->dado = 1;
    n2->dado = 3;
    n3->dado = 6;
    
    //fazer as conexoes entre os nos//
    inicio->prox = n1;
    n1->prox = n2;
    n2->prox = n3;
    n3->prox = NULL;
}

void listarLista(){
    struct No *noLigacao = inicio;
    printf("Os dados da lista dinamica são: \n");
    while(noLigacao != NULL){
        printf("|%d|", noLigacao->dado);
        noLigacao = noLigacao->prox;
        if(noLigacao != NULL)
            printf("---->");
        else
            printf("----|");
    }
}
