/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   listasdinamicas.h
 * Author: rafa-
 *
 * Created on 28 de Novembro de 2017, 12:32
 */

#ifndef LISTASDINAMICAS_H
#define LISTASDINAMICAS_H

struct No{
    int dado;
    struct No *prox;
};

void montarLista();
void listarLista();
#endif /* LISTASDINAMICAS_H */

