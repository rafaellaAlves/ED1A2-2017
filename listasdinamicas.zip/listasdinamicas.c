#include "listasdinamicas.h"
#include <stdio.h>
#include <stdlib.h>

struct No *inicioA;
struct No *nA1 = NULL;
struct No *nA2 = NULL;
struct No *nA3 = NULL;

void montrarLista(){
    //aloca memoria para cada nó//
    nA1 = malloc(sizeof(struct No));
    nA2 = malloc(sizeof(struct No));
    nA3 = malloc(sizeof(struct No));
    
    //atribui valores para os nós//
    nA1 ->dado = 10;
    nA2 ->dado = 11;
    nA3 ->dado = 12;
    
    //conecta os nós//
    inicioA = nA1;//aponta a cabeca para o primeiro nó//
    nA1 ->prox = nA2;
    nA2 ->prox = nA3;
    nA3 ->prox = NULL;//finaliza a lista//  
}

void listarLista(){
    struct No *noCorrente = inicioA;//comeca a partir do head//
    printf("\n\nOs elementos da lista encadeada sao: \n");
    while(noCorrente != NULL){
        printf("|%d|", noCorrente->dado);
        noCorrente = noCorrente->prox;
        if(noCorrente != NULL)
            printf("---->");
        else
            printf("----*");
    }
}


