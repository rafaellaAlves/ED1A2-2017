

#ifndef LISTASDINAMICAS_H
#define LISTASDINAMICAS_H

struct No{
    int dado;
    struct No *prox;
};


void montrarLista();
void listarLista();

#endif /* LISTASDINAMICAS_H */

